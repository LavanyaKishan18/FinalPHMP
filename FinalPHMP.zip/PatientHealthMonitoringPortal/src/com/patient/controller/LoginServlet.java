package com.patient.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.bo.PatientBO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String pId=request.getParameter("userid");
		String ppass=request.getParameter("password");
		String category = request.getParameter("category");
		PatientBO pbo=new PatientBO();
		boolean status = pbo.loginValidate(pId,ppass,category);
		System.out.println("my status"+status+" catagory"+category);
		if(status==true && category.equalsIgnoreCase("doctor")){
			RequestDispatcher rd=request.getRequestDispatcher("userdetails.jsp");
			rd.forward(request, response);
		}else if(status==true && category.equalsIgnoreCase("patient")){
			HttpSession hs=request.getSession();
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			hs.setAttribute("uId", pId);
			rd.forward(request, response);
		}else{
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			request.setAttribute("msg1", "Invalid Username and Password");
			rd.forward(request, response);
		}
		
		
	}

}
