package com.patient.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {
	String url = "jdbc:mysql://localhost:3306/patient";
	String username = "root";
	String password = "root";
	public List getpatientDetails()
	{
		List list=new ArrayList<>();
		try{
			String qry="select p.userid,p.firstname,p.gender,c.height,c.weight,p.age,c.bmi,"
					+ "b.rbccount,b.wbccount,b.plateletcount,d.glucose_level,d.diabetics_level"
					+ "from patient p,calculated_bmi c,bloodcount b,diabetics d where p.userid=c.id and b.patientid=d.userId";
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username,	password);
			PreparedStatement pstmt = con.prepareStatement(qry);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
			
			}
			
		}catch(Exception e)
		{
			
		}
		
		return null;
	}

}
