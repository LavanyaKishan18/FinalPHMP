package com.patient.bo;

import com.patient.dao.PatientDAO;
import com.patient.model.BMI;
import com.patient.model.Glucose;

public class PatientBO {
	PatientDAO pdao=new PatientDAO();
	public boolean loginValidate(String pId, String ppass, String category) {
			if(category.equalsIgnoreCase("doctor")){
				System.out.println("doctor is entered");
				return pdao.doctorLoginValidate(pId,ppass);
			}else{
				System.out.println("patient is entered");
				return pdao.patientLoginValidate(pId,ppass);
			}
		
	}
	public int updateBMI(BMI b) {
		
		return pdao.updateBMI(b);
	}
	public int updateGlucose(Glucose g) {
		
		return pdao.updateGlucose(g);
	}
	

}
