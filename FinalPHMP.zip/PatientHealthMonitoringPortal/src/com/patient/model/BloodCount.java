package com.patient.model;

public class BloodCount {
	private int patientId;
	private String timeOfTheDay;
	private String rbcCount;
	private String wbcCount;
	private String plateletCount;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getTimeOfTheDay() {
		return timeOfTheDay;
	}
	public void setTimeOfTheDay(String timeOfTheDay) {
		this.timeOfTheDay = timeOfTheDay;
	}
	public String getRbcCount() {
		return rbcCount;
	}
	public void setRbcCount(String rbcCount) {
		this.rbcCount = rbcCount;
	}
	public String getWbcCount() {
		return wbcCount;
	}
	public void setWbcCount(String wbcCount) {
		this.wbcCount = wbcCount;
	}
	public String getPlateletCount() {
		return plateletCount;
	}
	public void setPlateletCount(String plateletCount) {
		this.plateletCount = plateletCount;
	}
	
}
